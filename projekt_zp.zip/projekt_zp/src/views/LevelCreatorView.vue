<template>
    <LevelDisplay />

</template>

<script>

import LevelDisplay from '@/components/LevelDisplay.vue';

export default {
  components: {
    LevelDisplay
  }
}
</script>