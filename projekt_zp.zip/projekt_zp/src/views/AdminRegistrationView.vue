<template>

    <AdminRegistrationForm />

</template>

<script>
import AdminRegistrationForm from '../components/AdminRegistrationForm.vue';

export default {
  components: {
    AdminRegistrationForm
  }
}
</script>