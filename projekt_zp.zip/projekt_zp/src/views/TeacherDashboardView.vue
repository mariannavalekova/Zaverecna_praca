<template>

    <ClassDashboard />

</template>

<script>
import ClassDashboard from '../components/ClassDashboard.vue';

export default {
  components: {
    ClassDashboard
  }
}
</script>