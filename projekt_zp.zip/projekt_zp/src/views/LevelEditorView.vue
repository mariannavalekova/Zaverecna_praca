<template>
    <LevelEditor />

</template>

<script>

import LevelEditor from '@/components/LevelEditor.vue';

export default {
  components: {
    LevelEditor
  }
}
</script>