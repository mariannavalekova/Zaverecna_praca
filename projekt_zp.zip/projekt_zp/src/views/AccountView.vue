<template>

    <AccountSettingsForm />

</template>

<script>
import AccountSettingsForm from '../components/AccountSettingsForm.vue';

export default {
  components: {
    AccountSettingsForm
  }
}
</script>