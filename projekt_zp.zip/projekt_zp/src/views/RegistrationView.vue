<template>

    <RegistrationForm />

</template>

<script>
import RegistrationForm from '../components/RegistrationForm.vue';

export default {
  components: {
    RegistrationForm
  }
}
</script>